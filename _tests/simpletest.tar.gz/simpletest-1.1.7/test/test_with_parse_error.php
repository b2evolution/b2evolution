<?php
    // $Id$
    
    class TestCaseWithParseError extends UnitTestCase {
        wibble
    }
    
?>